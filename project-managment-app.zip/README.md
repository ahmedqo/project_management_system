# app features
516 Chapman St, Hillside, NJ 07205, 9735004188
### npx tailwindcss -i ./input.css -o ./public/css/app.css --watch

    [?] employees
    [+] departments
    [+] designations
    [+] contracts
    [+] insurances
    [+] discharges
    [+] leaves
    [+] clients
    [-] schedules
    [-] payments
    [-] bonus
    [-] tickets
    [-] promotions 

Monsieur le Directeur,

Je me permets de vous écrire pour vous faire part de ma décision de poursuivre mes études à l’Université. Je suis actuellement étudiant en systèmes d'information nomades et je souhaiterais continuer mon cursus jusqu’à l’obtention de mon diplôme.

Ayant pas réussi à valider tous mes modules lors de ma session précédente, je tiens à vous assurer de ma détermination à poursuivre mes études et à obtenir mon diplôme. Je promets de m'investir pleinement afin de mettre en pratique les compétences acquises et de réussir mes études.

Je vous remercie de l’attention que vous porterez à ma demande et je reste à votre disposition pour tout aut
 
