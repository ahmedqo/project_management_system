<?php

namespace App\Functions;

use App\Models\File;
use Illuminate\Support\Facades\Storage;

class FileFunction
{
    public static $BASEPATH = "/public/";

    public static function store($file, $path = '')
    {
        $path = Storage::putFile(FileFunction::$BASEPATH . $path, $file);
        $name = $file->getClientOrginalName();
        $type = $file->getClientMimeType();
        $size = $file->getSize();

        return File::create([
            'name' => $name,
            'path' => $path,
            'type' => $type,
            'size' => $size,
        ]);
    }

    public static function destroy($file, $path = '')
    {
        $data = File::where('id', $file)->first();
        if (Storage::exists(FileFunction::$BASEPATH . $path . $data->path))
            Storage::delete(FileFunction::$BASEPATH . $path . $data->path);
        $data->delete();
    }
}
