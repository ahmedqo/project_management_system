@extends('communs.base')
@section('title', 'Conversations')

@section('content')
    <div class="w-full bg-white rounded-lg -mt-12 overflow-hidden">
        <div class="p-4 flex items-center justify-between gap-4">
            <h1 class="font-black text-gray-900 text-2xl">
                Conversations
            </h1>
        </div>
    </div>

    <div class="grid grid-rows-1 grid-cols-1 lg:grid-cols-3 items-start gap-4">
        <div class="w-full bg-white p-4 rounded-lg lg:col-span-2 order-2 lg:order-1">
            <ul class="w-full flex flex-col gap-4">
                @forelse($conversations as $row)
                    <li
                        class="flex flex-col rounded-md items-end border border-gray-300 {{ $row->count > 0 ? 'bg-blue-50' : 'bg-gray-50' }}">
                        <div class="w-full p-2 flex justify-between items-center font-bold text-sm text-gray-900 flex-wrap">
                            <a href="{{ route('views.conversations.single', $row->conversation->id) }}"
                                class="block w-max max-w-[calc(100% - 2rem)] text-gray-900 font-bold text-sm hover:underline">
                                <span x-ucfirst>{{ $row->conversation->subject }}</span>
                            </a>
                            @if ($row->count > 0)
                                <span
                                    class="w-5 h-5 rounded-full text-sm font-black text-gray-50 bg-blue-400 flex items-center justify-center">{{ $row->count }}</span>
                            @endif
                        </div>
                        @if ($row->message)
                            <span class="border-b border-gray-300 w-full"></span>
                            <span x-ucfirst
                                class="w-full p-2 font-normal text-md block overflow-hidden whitespace-nowrap overflow-ellipsis">
                                {{ $row->message->content }}
                            </span>
                        @endif
                        <span class="border-b border-gray-300 w-full"></span>
                        <span class="text-gray-700 p-1 text-xs font-black">
                            {{ $row->message ? Carbon::parse($row->message->created_at)->diffForHumans() : Carbon::parse($row->created_at)->diffForHumans() }}
                        </span>
                    </li>
                @empty
                    <li class="flex flex-col gap-2 p-4 rounded-md items-end bg-gray-50 border border-gray-300">
                        <p x-ucfirst class="w-full text-gray-900 text-lg text-center uppercase">
                            no recoreds found
                        </p>
                    </li>
                @endforelse
            </ul>
        </div>
        <div class="sticky top-4 w-full bg-white p-4 rounded-lg order-1 lg:order-2">
            <form action="{{ route('actions.conversations.store') }}" method="POST" class="w-full flex flex-col gap-4">
                @csrf
                <div class="w-full">
                    <label x-ucfirst for="recipient" class="block text-sm font-black text-gray-900 mb-1">Recipient</label>
                    <div class="relative">
                        <select x-select id="recipient" placeholder="Recipient" name="recipient">
                            @foreach ($recipients as $recipient)
                                <option x-ucfirst value="{{ $recipient->id }}">
                                    {{ $recipient->firstName }} {{ $recipient->lastName }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="w-full">
                    <label x-ucfirst for="subject" class="block text-sm font-black text-gray-900 mb-1">Subject</label>
                    <div class="relative">
                        <input id="subject" placeholder="Subject" name="subject"
                            class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400" />
                    </div>
                </div>
                <div class="w-full">
                    <button type="submit"
                        class="appearance-none lg:w-max ml-auto text-md flex items-center justify-center rounded-md font-semibold w-full p-2 px-4 text-white outline-none bg-blue-400 hover:bg-blue-300 focus:bg-blue-300">
                        <span x-ucfirst>Create</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
@endsection
