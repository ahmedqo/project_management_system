<div
    class="hidden top-0 left-0 right-0 bottom-0 -translate-x-1/2 -translate-y-1/2 -right-1/2 -left-1/2 -top-full -bottom-full border-green-500 bg-green-300 border-blue-500 bg-blue-300 border-yellow-500 bg-yellow-300 border-red-500 bg-red-300 text-green-500 text-blue-500 text-yellow-500 text-red-500 bg-red-200 bg-yellow-200 bg-green-200 bg-blue-200 bg-gray-900 bg-opacity-20 border-blue-400 border-transparent bg-blue-900 bg-opacity-50">
</div>
