
<?php $__env->startSection('title', 'Projects view'); ?>
<?php $__env->startSection('content'); ?>
    <div class="w-full bg-white rounded-lg shadow-sm shadow-gray-300 -mt-12 overflow-hidden">
        <div class="p-4 flex items-center justify-between gap-4">
            <h1 class="font-black text-gray-900 text-2xl">
                <?php echo e(__('Projects \ View')); ?>

            </h1>
            <div class="w-max flex items-center gap-2">
                <a href="<?php echo e(route('views.projects.edit', $data->id)); ?>"
                    class="w-10 h-10 flex items-center justify-center rounded-full text-white bg-yellow-400 outline-none hover:bg-yellow-300 focus:bg-yellow-300">
                    <svg class="block w-5 h-5 pointer-events-none" fill="currentcolor" viewBox="0 0 48 48">
                        <path
                            d="M4.05 47.75v-6.9h39.9v6.9Zm3.75-12.2 6.35-6.35-.25-.15q-1.55-1.6-1.525-3.925Q12.4 22.8 14 21.2l7-7.05 12.15 12.1-7.2 7.2q-1.4 1.4-3.825 1.4-2.425 0-3.775-1.4l-.45-.55-2.7 2.65ZM35.3 24.1 23.2 11.95l8.4-8.35q1.4-1.45 3.25-1.45T38.2 3.6l5.35 5.45q1.4 1.4 1.375 3.4-.025 2-1.425 3.45Z" />
                    </svg>
                </a>
            </div>
        </div>
    </div>

    <div class="w-full bg-white rounded-lg shadow-sm shadow-gray-300 overflow-hidden flex flex-col lg:col-span-12">
        <div class="relative w-full overflow-y-auto">
            <div class="w-full absolute bottom-0 left-0 border-b border-gray-300"></div>
            <div class="flex w-max flex-wrap relative">
                <button x-tab="#summary"
                    class="appearance-none w-max text-md flex items-center justify-center font-semibold p-2 px-4 text-gray-900 outline-none  hover:border-blue-400 focus:border-blue-400 border-b-4 border-blue-400">
                    <span>Summary</span>
                </button>
                <button x-tab="#tasks"
                    class="appearance-none w-max text-md flex items-center justify-center font-semibold p-2 px-4 text-gray-900 outline-none  hover:border-blue-400 focus:border-blue-400 border-b-4 border-transparent">
                    <span>tasks</span>
                </button>
                <button x-tab="#documents"
                    class="appearance-none w-max text-md flex items-center justify-center font-semibold p-2 px-4 text-gray-900 outline-none  hover:border-blue-400 focus:border-blue-400 border-b-4 border-transparent">
                    <span>Documents</span>
                </button>
            </div>
        </div>
        <div class="w-full p-4">
            <div id="summary"">
                <div class="grid grid-rows-1 grid-cols-1 lg:grid-cols-3 items-start gap-4">
                    <div class="w-full flex items-center gap-4 overflow-hidden p-4 border border-gray-300 rounded-md">
                        <div class="flex-1 flex flex-col">
                            <h2 class="font-semibold text-xl text-gray-900">Progress</h2>
                            <span id="display" class="text-gray-900 text-md px-2"></span>
                        </div>
                        <div id="pie" class="block w-12 h-12"></div>
                    </div>
                    <div class="w-full flex items-center gap-4 overflow-hidden p-4 border border-gray-300 rounded-md">
                        <div class="flex-1 flex flex-col">
                            <h2 class="font-semibold text-xl text-gray-900">Client</h2>
                            <span class="text-gray-900 text-md px-2">
                                <?php echo e(ucfirst($data->client()->first()->name)); ?>

                            </span>
                        </div>
                        <svg class="block w-12 h-12 text-purple-500 pointer-events-none" fill="currentcolor"
                            viewBox="0 0 48 48">
                            <path
                                d="M36.95 29.95q-.9-2.05-2.25-3.15T31 24.75l-11.35-4.1q-.75-.25-1.525-.35-.775-.1-1.775-.1H14.9v-5.45q0-1.1.475-2.05.475-.95 1.425-1.65l9.65-6.95q1.25-.85 2.7-.85 1.45 0 2.7.85l9.7 6.95q.9.7 1.425 1.65t.525 2.05v15.2Zm-5.8-13.4q.55 0 .9-.35t.35-.9q0-.45-.35-.825-.35-.375-.9-.375-.5 0-.875.375t-.375.875q0 .5.375.85t.875.35Zm-4 0q.55 0 .9-.35t.35-.9q0-.45-.35-.825-.35-.375-.9-.375-.5 0-.875.375t-.375.875q0 .5.375.85t.875.35Zm4 4q.5 0 .875-.35t.375-.9q0-.45-.35-.825-.35-.375-.9-.375-.5 0-.875.375t-.375.875q0 .5.35.85t.9.35Zm-4 0q.5 0 .875-.325t.375-.875q0-.5-.375-.875t-.875-.375q-.55 0-.9.375t-.35.875q0 .55.35.875.35.325.9.325ZM.5 41.55V26.4q0-1.3.925-2.25t2.325-.95h1.7q1.3 0 2.225.95T8.6 26.4v15.15q0 1.35-.925 2.275-.925.925-2.225.925h-1.7q-1.4 0-2.325-.925Q.5 42.9.5 41.55Zm25.95 4.95L11.7 42.25V23.2h4.55q.5 0 .85.125t.75.175L29 27.65q2.1.75 3.4 2.45 1.3 1.7 1.3 3.45 0 .05-.1.175-.1.125-.2.125h-4.1q-1.7 0-3.15-.225T23 32.9l-2.65-.8q-.5-.1-.975.1t-.575.65q-.15.65.05 1.15.2.5.75.6l2.35.75q1.25.45 3.15.75t4.55.3h9.25q3.5 0 4.475 1.35.975 1.35.975 4.5l-15.4 4.3q-.65.25-1.25.225-.6-.025-1.25-.275Z">
                            </path>
                        </svg>
                    </div>
                    <div class="w-full flex items-center gap-4 overflow-hidden p-4 border border-gray-300 rounded-md">
                        <div class="flex-1 flex flex-col">
                            <h2 class="font-semibold text-xl text-gray-900">Budget</h2>
                            <span class="text-gray-900 text-md px-2">
                                <?php echo e($data->budget); ?> DH
                            </span>
                        </div>
                        <svg class="block w-12 h-12 text-green-500 pointer-events-none" fill="currentcolor"
                            viewBox="0 0 48 48">
                            <path
                                d="M24.15 42.45q-.75 0-1.225-.45-.475-.45-.475-1.25v-2.6q-2.6-.4-4.325-1.775T15.4 32.95q-.4-.65.025-1.45.425-.8 1.225-1.2.65-.15 1.375.075.725.225 1.275 1.025.85 1.55 2.2 2.25t2.95.7q2.25 0 3.625-1.05t1.375-2.8q0-2-1.4-3.175-1.4-1.175-5.25-2.375-3.45-1-5.25-3.05-1.8-2.05-1.8-5.05 0-2.6 1.625-4.575T22.45 9.8V7.2q0-.75.475-1.2.475-.45 1.225-.45.7 0 1.2.45t.5 1.2v2.6q1.7.35 3.25 1.175 1.55.825 2.55 2.275.4.65.125 1.425T30.65 15.8q-.6.25-1.35.025-.75-.225-1.45-.875T26.2 13.9q-.95-.4-2.1-.4-2.15 0-3.25.85t-1.1 2.4q0 1.55 1.225 2.675Q22.2 20.55 26.4 21.8q3.5 1.2 5.225 3.225Q33.35 27.05 33.45 30.3q0 3.25-1.925 5.3t-5.675 2.6v2.55q0 .8-.5 1.25-.5.45-1.2.45Z">
                            </path>
                        </svg>
                    </div>
                    <div class="w-full lg:col-span-2 border border-gray-300 rounded-md">
                        <div class="w-full flex flex-col">
                            <h2 class="font-black text-2xl text-gray-900 p-4">
                                <?php echo e($data->name); ?>

                            </h2>
                            <span class="w-full border-t border-gray-300"></span>
                            <div class="w-full flex flex-col lg:flex-row lg:flex-wrap lg:justify-between gap-4 p-4">
                                <div class="w-full lg:w-max">
                                    <label class="block text-sm font-black text-gray-900 mb-1">Status</label>
                                    <span class="text-gray-900 text-md block w-full px-2">
                                        <?php echo e(ucfirst($data->status)); ?>

                                    </span>
                                </div>
                                <div class="w-full lg:w-max">
                                    <label class="block text-sm font-black text-gray-900 mb-1">Create date</label>
                                    <span class="text-gray-900 text-md block w-full px-2">
                                        <?php echo e(Carbon::parse($data->created_at)->diffForHumans()); ?>

                                    </span>
                                </div>
                                <div class="w-full lg:w-max">
                                    <label class="block text-sm font-black text-gray-900 mb-1">Update date</label>
                                    <span class="text-gray-900 text-md block w-full px-2">
                                        <?php echo e(Carbon::parse($data->updated_at)->diffForHumans()); ?>

                                    </span>
                                </div>
                            </div>
                            <span class="w-full border-t border-gray-300"></span>
                            <div class="w-full flex flex-col gap-2 p-4">
                                <h2 class="font-semibold text-xl text-gray-900">
                                    Description
                                </h2>
                                <p class="text-lg text-gray-900">
                                    <?php echo e(strlen($data->description) ? $data->description : 'N/A'); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="w-full flex flex-col gap-4">
                        <div class="w-full flex items-center gap-4 overflow-hidden p-4 border border-gray-300 rounded-md">
                            <div class="flex-1 flex flex-col">
                                <h2 class="font-semibold text-xl text-gray-900">Manager</h2>
                                <span class="text-gray-900 text-md px-2">
                                    <?php echo e($data->manager()->first()->firstName); ?>

                                    <?php echo e(strtoupper($data->manager()->first()->lastName)); ?>

                                </span>
                            </div>
                            <svg class="block w-12 h-12 text-purple-500 pointer-events-none" fill="currentcolor"
                                viewBox="0 0 48 48">
                                <path
                                    d="M36.95 29.95q-.9-2.05-2.25-3.15T31 24.75l-11.35-4.1q-.75-.25-1.525-.35-.775-.1-1.775-.1H14.9v-5.45q0-1.1.475-2.05.475-.95 1.425-1.65l9.65-6.95q1.25-.85 2.7-.85 1.45 0 2.7.85l9.7 6.95q.9.7 1.425 1.65t.525 2.05v15.2Zm-5.8-13.4q.55 0 .9-.35t.35-.9q0-.45-.35-.825-.35-.375-.9-.375-.5 0-.875.375t-.375.875q0 .5.375.85t.875.35Zm-4 0q.55 0 .9-.35t.35-.9q0-.45-.35-.825-.35-.375-.9-.375-.5 0-.875.375t-.375.875q0 .5.375.85t.875.35Zm4 4q.5 0 .875-.35t.375-.9q0-.45-.35-.825-.35-.375-.9-.375-.5 0-.875.375t-.375.875q0 .5.35.85t.9.35Zm-4 0q.5 0 .875-.325t.375-.875q0-.5-.375-.875t-.875-.375q-.55 0-.9.375t-.35.875q0 .55.35.875.35.325.9.325ZM.5 41.55V26.4q0-1.3.925-2.25t2.325-.95h1.7q1.3 0 2.225.95T8.6 26.4v15.15q0 1.35-.925 2.275-.925.925-2.225.925h-1.7q-1.4 0-2.325-.925Q.5 42.9.5 41.55Zm25.95 4.95L11.7 42.25V23.2h4.55q.5 0 .85.125t.75.175L29 27.65q2.1.75 3.4 2.45 1.3 1.7 1.3 3.45 0 .05-.1.175-.1.125-.2.125h-4.1q-1.7 0-3.15-.225T23 32.9l-2.65-.8q-.5-.1-.975.1t-.575.65q-.15.65.05 1.15.2.5.75.6l2.35.75q1.25.45 3.15.75t4.55.3h9.25q3.5 0 4.475 1.35.975 1.35.975 4.5l-15.4 4.3q-.65.25-1.25.225-.6-.025-1.25-.275Z">
                                </path>
                            </svg>
                        </div>
                        <div class="w-full flex flex-col overflow-hidden p-4 border border-gray-300 rounded-md">
                            <h2 class="font-semibold text-xl text-gray-900">Team</h2>
                            <ul class="w-full">
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="text-gray-900 text-md px-2 flex flex-wrap items-center gap-2">
                                        <span class="w-2 h-2 rounded-full bg-gray-300"></span>
                                        <p>
                                            <?php echo e($employee->employee()->first()->firstName); ?>

                                            <?php echo e(strtoupper($employee->employee()->first()->lastName)); ?>

                                        </p>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div id="tasks" class="hidden flex-col items-end gap-4">
                <div class="w-max flex items-center gap-2">
                    <a href="<?php echo e(route('views.projects.create')); ?>"
                        class="w-10 h-10 flex items-center justify-center rounded-full text-white bg-blue-400 outline-none hover:bg-blue-300 focus:bg-blue-300">
                        <svg class="block w-5 h-5 pointer-events-none" fill="currentcolor" viewBox="0 0 48 48">
                            <path
                                d="M24 38.75q-.95 0-1.6-.625-.65-.625-.65-1.675V26.3H11.5q-.9 0-1.575-.675Q9.25 24.95 9.25 24q0-1 .675-1.625t1.575-.625h10.25V11.5q0-1 .675-1.625T24 9.25q.95 0 1.625.625T26.3 11.5v10.25h10.2q.95 0 1.625.625T38.8 24q0 1-.675 1.65-.675.65-1.625.65H26.3v10.15q0 1.05-.675 1.675T24 38.75Z" />
                        </svg>
                    </a>
                </div>
                <div class="w-full">
                    <table x-table>
                        <thead>
                            <tr>
                                <td>
                                    name
                                </td>
                                <td>
                                    priority
                                </td>
                                <td>
                                    due date
                                </td>
                                <td>
                                    status
                                </td>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
            <div id="documents" class="hidden flex-col gap-4"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        const tabs = Array.from(document.querySelectorAll('[x-tab]'));
        tabs.forEach(tab => {
            const target = document.querySelector(`${tab.getAttribute("x-tab")}`);
            tab.addEventListener("click", e => {
                tabs.forEach(_tab => {
                    const _target = document.querySelector(`${_tab.getAttribute("x-tab")}`);
                    classes.remove(_tab, "border-blue-400");
                    classes.add(_tab, "border-transparent");
                    classes.remove(_target, "flex");
                    classes.add(_target, "hidden");
                });
                classes.remove(tab, "border-transparent");
                classes.add(tab, "border-blue-400");
                classes.remove(target, "hidden");
                classes.add(target, "flex");
            })
        })
    </script>
    <script>
        Program.pie(pie, {
            values: {
                "filled properties": 50,
                "available properties": 90,
            },
            colors: ["#60A5FA", "#f3f4f6"],
            callback: ($) => {
                display.innerHTML = $.percentageString(Object.values($.values)[0])
            },
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('communs.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmedqo\Desktop\rentify-app\resources\views/project/view.blade.php ENDPATH**/ ?>