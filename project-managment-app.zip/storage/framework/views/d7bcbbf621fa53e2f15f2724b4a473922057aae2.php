
<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
    <div class="w-full bg-white rounded-lg shadow-sm shadow-gray-300 -mt-12 overflow-hidden">
        <div class="p-4 flex items-center justify-between gap-4">
            <h1 class="font-black text-gray-900 text-2xl">
                <?php echo e(__('Profile')); ?>

            </h1>
            <div class="w-max flex items-center gap-2">
                <a href="#"
                    class="w-10 h-10 flex items-center justify-center rounded-full text-white bg-yellow-400 outline-none hover:bg-yellow-300 focus:bg-yellow-300">
                    <svg class="block w-5 h-5 pointer-events-none" fill="currentcolor" viewBox="0 0 48 48">
                        <path
                            d="M4.05 47.75v-6.9h39.9v6.9Zm3.75-12.2 6.35-6.35-.25-.15q-1.55-1.6-1.525-3.925Q12.4 22.8 14 21.2l7-7.05 12.15 12.1-7.2 7.2q-1.4 1.4-3.825 1.4-2.425 0-3.775-1.4l-.45-.55-2.7 2.65ZM35.3 24.1 23.2 11.95l8.4-8.35q1.4-1.45 3.25-1.45T38.2 3.6l5.35 5.45q1.4 1.4 1.375 3.4-.025 2-1.425 3.45Z" />
                    </svg>
                </a>
            </div>
        </div>
    </div>

    <div class="w-full bg-white rounded-lg shadow-sm shadow-gray-300 overflow-hidden flex flex-col lg:col-span-12">
        <div class="relative w-full overflow-y-auto">
            <div class="w-full absolute bottom-0 left-0 border-b border-gray-300"></div>
            <div class="flex w-max flex-wrap relative">
                <button x-tab="#info"
                    class="appearance-none w-max text-md flex items-center justify-center font-semibold p-2 px-4 text-gray-900 outline-none  hover:border-blue-400 focus:border-blue-400 border-b-4 border-blue-400">
                    <span>Info</span>
                </button>
                <button x-tab="#contracts"
                    class="appearance-none w-max text-md flex items-center justify-center font-semibold p-2 px-4 text-gray-900 outline-none  hover:border-blue-400 focus:border-blue-400 border-b-4 border-transparent">
                    <span>Contracts</span>
                </button>
                <button x-tab="#leaves"
                    class="appearance-none w-max text-md flex items-center justify-center font-semibold p-2 px-4 text-gray-900 outline-none  hover:border-blue-400 focus:border-blue-400 border-b-4 border-transparent">
                    <span>Leaves</span>
                </button>
                <button x-tab="#accounts"
                    class="appearance-none w-max text-md flex items-center justify-center font-semibold p-2 px-4 text-gray-900 outline-none  hover:border-blue-400 focus:border-blue-400 border-b-4 border-transparent">
                    <span>Accounts</span>
                </button>
                <button x-tab="#documents"
                    class="appearance-none w-max text-md flex items-center justify-center font-semibold p-2 px-4 text-gray-900 outline-none  hover:border-blue-400 focus:border-blue-400 border-b-4 border-transparent">
                    <span>Documents</span>
                </button>
            </div>
        </div>
        <div class="w-full p-4">
            <div id="info" class="flex flex-col lg:flex-row gap-4">
                <div class="w-full flex flex-col gap-4">
                    <div x-toggle="#general, #sub-show-1, #sub-hide-1" x-property="hidden, flex"
                        class="w-full flex flex-wrap justify-between items-center gap-2 border-b border-gray-300">
                        <h2 class="w-max text-lg font-black text-gray-900">General</h2>
                        <svg id="sub-show-1" class="flex w-6 h-6 text-gray-900 pointer-events-none" fill="currentcolor"
                            viewBox="0 0 48 48">
                            <path d="M24 31.8 10.9 18.7 14.2 15.45 24 25.35 33.85 15.5 37.1 18.75Z"></path>
                        </svg>
                        <svg id="sub-hide-1" class="hidden w-6 h-6 pointer-events-none" fill="currentcolor"
                            viewBox="0 0 48 48">
                            <path
                                d="M17.2 35.45q-.7-.75-.7-1.675t.7-1.575l8.2-8.25-8.25-8.3q-.7-.6-.675-1.6.025-1 .725-1.65.65-.7 1.575-.675.925.025 1.575.675l9.95 9.95q.3.3.5.725t.2.875q0 .5-.2.9t-.5.7l-9.9 9.9q-.65.65-1.6.625-.95-.025-1.6-.625Z" />
                        </svg>
                    </div>
                    <div id="general" class="w-full flex flex-col gap-4">
                        <div class="grid grid-rows-1 grid-cols-1 lg:grid-cols-2 gap-4">
                            <div class="w-full">
                                <label class="block text-sm font-black text-gray-900 mb-1">First name</label>
                                <input
                                    class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400"
                                    value="<?php echo e($data->firstName); ?>" readonly />
                            </div>
                            <div class="w-full">
                                <label class="block text-sm font-black text-gray-900 mb-1">Last name</label>
                                <input
                                    class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400"
                                    value="<?php echo e(strtoupper($data->lastName)); ?>" readonly />
                            </div>
                        </div>
                        <div class="grid grid-rows-1 grid-cols-1 lg:grid-cols-2 gap-4">
                            <div class="w-full">
                                <label class="block text-sm font-black text-gray-900 mb-1">Birth date</label>
                                <input
                                    class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400"
                                    value="<?php echo e($data->birthDate); ?>" readonly />
                            </div>
                            <div class="w-full">
                                <label class="block text-sm font-black text-gray-900 mb-1">Gender</label>
                                <input
                                    class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400"
                                    value="<?php echo e($data->gender); ?>" readonly />
                            </div>
                        </div>
                        <div class="grid grid-rows-1 grid-cols-1 lg:grid-cols-2 gap-4">
                            <div class="w-full">
                                <label class="block text-sm font-black text-gray-900 mb-1">Identity</label>
                                <input
                                    class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400"
                                    value="<?php echo e($data->identity); ?>" readonly />
                            </div>
                            <div class="w-full">
                                <label class="block text-sm font-black text-gray-900 mb-1">Identity type</label>
                                <input
                                    class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400"
                                    value="<?php echo e($data->identityType); ?>" readonly />
                            </div>
                        </div>
                    </div>
                    <div x-toggle="#contact, #sub-show-2, #sub-hide-2" x-property="hidden, flex"
                        class="w-full flex flex-wrap justify-between items-center gap-2 border-b border-gray-300">
                        <h2 class="w-max text-lg font-black text-gray-900">Contact</h2>
                        <svg id="sub-show-2" class="hidden w-6 h-6 text-gray-900 pointer-events-none" fill="currentcolor"
                            viewBox="0 0 48 48">
                            <path d="M24 31.8 10.9 18.7 14.2 15.45 24 25.35 33.85 15.5 37.1 18.75Z"></path>
                        </svg>
                        <svg id="sub-hide-2" class="flex w-6 h-6 pointer-events-none" fill="currentcolor"
                            viewBox="0 0 48 48">
                            <path
                                d="M17.2 35.45q-.7-.75-.7-1.675t.7-1.575l8.2-8.25-8.25-8.3q-.7-.6-.675-1.6.025-1 .725-1.65.65-.7 1.575-.675.925.025 1.575.675l9.95 9.95q.3.3.5.725t.2.875q0 .5-.2.9t-.5.7l-9.9 9.9q-.65.65-1.6.625-.95-.025-1.6-.625Z" />
                        </svg>
                    </div>
                    <div id="contact" class="w-full hidden flex-col gap-4">
                        <div class="grid grid-rows-1 grid-cols-1 lg:grid-cols-2 gap-4">
                            <div class="w-full">
                                <label class="block text-sm font-black text-gray-900 mb-1">Email</label>
                                <input
                                    class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400"
                                    value="<?php echo e($data->email); ?>" readonly />
                            </div>
                            <div class="w-full">
                                <label class="block text-sm font-black text-gray-900 mb-1">Phone</label>
                                <input
                                    class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400"
                                    value="<?php echo e($data->phone); ?>" readonly />
                            </div>
                        </div>
                        <div class="w-full">
                            <label class="block text-sm font-black text-gray-900 mb-1">Address</label>
                            <textarea
                                class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400"
                                readonly><?php echo e($data->address); ?></textarea>
                        </div>
                    </div>
                    <div x-toggle="#affiliation, #sub-show-3, #sub-hide-3" x-property="hidden, flex"
                        class="w-full flex flex-wrap justify-between items-center gap-2 border-b border-gray-300">
                        <h2 class="w-max text-lg font-black text-gray-900">Affiliation</h2>
                        <svg id="sub-show-3" class="hidden w-6 h-6 text-gray-900 pointer-events-none" fill="currentcolor"
                            viewBox="0 0 48 48">
                            <path d="M24 31.8 10.9 18.7 14.2 15.45 24 25.35 33.85 15.5 37.1 18.75Z"></path>
                        </svg>
                        <svg id="sub-hide-3" class="flex w-6 h-6 pointer-events-none" fill="currentcolor"
                            viewBox="0 0 48 48">
                            <path
                                d="M17.2 35.45q-.7-.75-.7-1.675t.7-1.575l8.2-8.25-8.25-8.3q-.7-.6-.675-1.6.025-1 .725-1.65.65-.7 1.575-.675.925.025 1.575.675l9.95 9.95q.3.3.5.725t.2.875q0 .5-.2.9t-.5.7l-9.9 9.9q-.65.65-1.6.625-.95-.025-1.6-.625Z" />
                        </svg>
                    </div>
                    <div id="affiliation" class="w-full hidden flex-col gap-4">
                        <div class="grid grid-rows-1 grid-cols-1 lg:grid-cols-2 gap-4">
                            <div class="w-full">
                                <label class="block text-sm font-black text-gray-900 mb-1">Department</label>
                                <input
                                    class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400"
                                    value="<?php echo e($data->department()->first()->name); ?>" readonly />
                            </div>
                            <div class="w-full">
                                <label class="block text-sm font-black text-gray-900 mb-1">Designation</label>
                                <input
                                    class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400"
                                    value="<?php echo e($data->designation()->first()->name); ?>" readonly />
                            </div>
                        </div>
                        <div class="grid grid-rows-1 grid-cols-1 lg:grid-cols-2 gap-4">
                            <div class="w-full">
                                <label class="block text-sm font-black text-gray-900 mb-1">Insurance</label>
                                <input
                                    class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400"
                                    value="<?php echo e($data->insurance()->first()->name); ?>" readonly />
                            </div>
                            <div class="w-full">
                                <label class="block text-sm font-black text-gray-900 mb-1">Insurance company</label>
                                <input
                                    class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400"
                                    value="<?php echo e($data->insurance()->first()->company); ?>" readonly />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="contracts" class="hidden flex-col gap-4">
                <div class="w-full">
                    <table x-table>
                        <thead>
                            <tr>
                                <td>
                                    Type
                                </td>
                                <td>
                                    Salary
                                </td>
                                <td>
                                    Compensation
                                </td>
                                <td>
                                    Start date
                                </td>
                                <td>
                                    End date
                                </td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($contract->type); ?>

                                    </td>
                                    <td>
                                        <?php echo e($contract->salary); ?> DH
                                    </td>
                                    <td>
                                        <?php echo e(ucfirst($contract->compensation)); ?>

                                    </td>
                                    <td>
                                        <?php echo e(Carbon::parse($contract->startDate)->diffForHumans()); ?>

                                    </td>
                                    <td>
                                        <?php echo e(Carbon::parse($contract->endDate)->diffForHumans()); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div id="leaves" class="hidden flex-col gap-4">
                <div class="w-full">
                    <table x-table>
                        <thead>
                            <tr>
                                <td>
                                    type
                                </td>
                                <td>
                                    count
                                </td>
                                <td>
                                    start date
                                </td>
                                <td>
                                    end date
                                </td>
                                <td>
                                    status
                                </td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e(ucfirst($leave->type)); ?>

                                    </td>
                                    <td>
                                        <?php echo e(abs(round((strtotime($leave->endDate) - strtotime($leave->startDate)) / 86400))); ?>

                                    </td>
                                    <td>
                                        <?php echo e(Carbon::parse($leave->startDate)->diffForHumans()); ?>

                                    </td>
                                    <td>
                                        <?php echo e(Carbon::parse($leave->endDate)->diffForHumans()); ?>

                                    </td>
                                    <td>
                                        <?php echo e(ucfirst($leave->status)); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div id="accounts" class="hidden flex-col gap-4">
                <div class="w-full">
                    <table x-table>
                        <thead>
                            <tr>
                                <td>
                                    Bank
                                </td>
                                <td>
                                    Rib
                                </td>
                                <td>
                                    Create date
                                </td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e(ucfirst($account->account()->first()->bank)); ?>

                                    </td>
                                    <td>
                                        <?php echo e($account->account()->first()->rib); ?>

                                    </td>
                                    <td>
                                        <?php echo e(Carbon::parse($account->account()->first()->created_at)->diffForHumans()); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div id="documents" class="hidden flex-col gap-4"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
    <script>
        const tabs = Array.from(document.querySelectorAll('[x-tab]'));
        tabs.forEach(tab => {
            const target = document.querySelector(`${tab.getAttribute("x-tab")}`);
            tab.addEventListener("click", e => {
                tabs.forEach(_tab => {
                    const _target = document.querySelector(`${_tab.getAttribute("x-tab")}`);
                    classes.remove(_tab, "border-blue-400");
                    classes.add(_tab, "border-transparent");
                    classes.remove(_target, "flex");
                    classes.add(_target, "hidden");
                });
                classes.remove(tab, "border-transparent");
                classes.add(tab, "border-blue-400");
                classes.remove(target, "hidden");
                classes.add(target, "flex");
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('communs.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmedqo\Desktop\rentify-app\resources\views/employee/profile.blade.php ENDPATH**/ ?>