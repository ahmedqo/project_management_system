
<?php $__env->startSection('title', 'Profile leaves'); ?>
<?php $__env->startSection('content'); ?>
    <div class="w-full bg-white rounded-lg shadow-sm shadow-gray-300 -mt-12 overflow-hidden">
        <div class="p-4 flex items-center justify-between gap-4">
            <h1 class="font-black text-gray-900 text-2xl">
                <?php echo e(__('Profile \ Leaves')); ?>

            </h1>
        </div>
        <div class="w-full overflow-y-auto">
            <div class="flex w-max flex-wrap">
                <a href="<?php echo e(route('views.profile.summary')); ?>"
                    class="appearance-none w-max text-md flex items-center justify-center font-semibold p-2 px-4 text-gray-900 outline-none  hover:border-blue-400 focus:border-blue-400 border-b-4 <?php echo e(Link::sub('views.profile.summary')); ?>">
                    <span>Summary</span>
                </a>
                <a href="<?php echo e(route('views.profile.contracts')); ?>"
                    class="appearance-none w-max text-md flex items-center justify-center font-semibold p-2 px-4 text-gray-900 outline-none  hover:border-blue-400 focus:border-blue-400 border-b-4 <?php echo e(Link::sub('views.profile.contracts')); ?>">
                    <span>Contracts</span>
                </a>
                <a href="<?php echo e(route('views.profile.leaves')); ?>"
                    class="appearance-none w-max text-md flex items-center justify-center font-semibold p-2 px-4 text-gray-900 outline-none  hover:border-blue-400 focus:border-blue-400 border-b-4 <?php echo e(Link::sub('views.profile.leaves')); ?>">
                    <span>Leaves</span>
                </a>
                <a href="<?php echo e(route('views.profile.accounts')); ?>"
                    class="appearance-none w-max text-md flex items-center justify-center font-semibold p-2 px-4 text-gray-900 outline-none  hover:border-blue-400 focus:border-blue-400 border-b-4 <?php echo e(Link::sub('views.profile.accounts')); ?>">
                    <span>Accounts</span>
                </a>
                <a x-tab="#documents"
                    class="appearance-none w-max text-md flex items-center justify-center font-semibold p-2 px-4 text-gray-900 outline-none  hover:border-blue-400 focus:border-blue-400 border-b-4 <?php echo e(Link::sub('views.profile.documents')); ?>">
                    <span>Documents</span>
                </a>
            </div>
        </div>
    </div>

    <div class="flex flex-col gap-4 bg-white rounded-lg shadow-sm shadow-gray-300 p-4">
        <table x-table>
            <thead>
                <tr>
                    <td>
                        type
                    </td>
                    <td>
                        count
                    </td>
                    <td>
                        start date
                    </td>
                    <td>
                        end date
                    </td>
                    <td>
                        status
                    </td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e(ucfirst($leave->type)); ?>

                        </td>
                        <td>
                            <?php echo e(abs(round((strtotime($leave->endDate) - strtotime($leave->startDate)) / 86400))); ?>

                        </td>
                        <td>
                            <?php echo e(Carbon::parse($leave->startDate)->diffForHumans()); ?>

                        </td>
                        <td>
                            <?php echo e(Carbon::parse($leave->endDate)->diffForHumans()); ?>

                        </td>
                        <td>
                            <?php echo e(ucfirst($leave->status)); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('communs.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmedqo\Desktop\rentify-app\resources\views/profile/leave.blade.php ENDPATH**/ ?>