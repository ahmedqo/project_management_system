<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(__('HA Groupe')); ?></title>
</head>

<body class="flex flex-col lg:flex-row bg-gray-50">
    <main class="w-full h-screen container mx-auto p-4">
        <section class="w-full h-full flex items-center justify-center">
            <div class="w-full grid grid-rows-1 grid-cols-1 lg:grid-cols-2 gap-20 items-center">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </section>
    </main>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php if(Session::has('message')): ?>
        <script>
            const info = <?php echo json_encode(Session::all()); ?>;
            const message = (Array.isArray(info.message) ? info.message : [info.message]).join("<br />");
            const type = info.type;
            (new Toaster({
                positionX: "right",
                positionY: "bottom",
                width: 500
            }))[type](message);
        </script>
    <?php endif; ?>
    <script>
        Program
            .ucfirst()
            .toggle()
            .password();
    </script>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH C:\Users\ahmedqo\Desktop\rentify-app\resources\views/auth/base.blade.php ENDPATH**/ ?>