<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
    <title><?php echo $__env->yieldContent('title'); ?> | Rentify</title>
</head>

<body class="flex flex-col lg:flex-row bg-gray-50">
    <main class="w-full h-screen container mx-auto p-4">
        <section class="w-full h-full flex items-center justify-center">
            <div class="w-full grid grid-rows-1 grid-cols-1 lg:grid-cols-2 gap-20 items-center">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </section>
    </main>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php if(Session::has('message')): ?>
        <script>
            var message = "<?php echo e(Session::get('message')); ?>",
                type = "<?php echo e(Session::get('type', 'info')); ?>";
            (new Toaster())[type](message);
        </script>
    <?php endif; ?>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH C:\Users\ahmedqo\Desktop\rentify-app\resources\views/_auth/base.blade.php ENDPATH**/ ?>