
<?php $__env->startSection('title', 'New Contact'); ?>

<?php $__env->startSection('content'); ?>
    <div class="w-full bg-white rounded-lg -mt-12 overflow-hidden">
        <div class="p-4 flex items-center justify-between gap-4">
            <h1 class="font-black text-gray-900 text-2xl">
                New Contact
            </h1>
        </div>
    </div>

    <div class="grid grid-rows-1 grid-cols-1 gap-4">
        <div class="w-full bg-white p-4 rounded-lg ">
            <form action="<?php echo e(route('actions.contacts.store')); ?>" method="POST" class="w-full flex flex-col gap-4">
                <?php echo csrf_field(); ?>
                <div class="w-full">
                    <label x-ucfirst for="client" class="block text-sm font-black text-gray-900 mb-1">Client</label>
                    <div class="relative">
                        <select x-select id="client" placeholder="Client" name="client">
                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option x-ucfirst value="<?php echo e($client->id); ?>">
                                    <?php echo e($client->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="grid grid-rows-1 grid-cols-1 lg:grid-cols-3 gap-4">
                    <div class="w-full">
                        <label x-ucfirst for="title" class="block text-sm font-black text-gray-900 mb-1">Title</label>
                        <div class="relative">
                            <select x-select id="title" placeholder="Title" name="title">
                                <option x-ucfirst value="madame">Madame</option>
                                <option x-ucfirst value="mister">Mister</option>
                            </select>
                        </div>
                    </div>
                    <div class="w-full">
                        <label x-ucfirst for="firstName" class="block text-sm font-black text-gray-900 mb-1">First
                            name</label>
                        <div class="relative">
                            <input id="firstName" type="text" placeholder="First name" name="firstName"
                                class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400" />
                        </div>
                    </div>
                    <div class="w-full">
                        <label x-ucfirst for="lastName" class="block text-sm font-black text-gray-900 mb-1">Last
                            name</label>
                        <div class="relative">
                            <input id="lastName" type="text" placeholder="Last name" name="lastName"
                                class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400" />
                        </div>
                    </div>
                </div>
                <div class="grid grid-rows-1 grid-cols-1 lg:grid-cols-3 gap-4">
                    <div class="w-full">
                        <label x-ucfirst for="function" class="block text-sm font-black text-gray-900 mb-1">Function</label>
                        <input id="function" type="text" placeholder="Function" name="function"
                            class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400" />
                    </div>
                    <div class="w-full">
                        <label x-ucfirst for="email" class="block text-sm font-black text-gray-900 mb-1">Email</label>
                        <div class="relative">
                            <input id="email" type="email" placeholder="Email" name="email"
                                class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400" />
                        </div>
                    </div>
                    <div class="w-full">
                        <label x-ucfirst for="phone" class="block text-sm font-black text-gray-900 mb-1">Phone</label>
                        <div class="relative">
                            <input id="phone" type="tel" placeholder="Phone" name="phone"
                                class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400" />
                        </div>
                    </div>
                </div>
                <div class="w-full">
                    <button type="submit"
                        class="appearance-none lg:w-max ml-auto text-md flex items-center justify-center rounded-md font-semibold w-full p-2 px-4 text-white outline-none bg-blue-400 hover:bg-blue-300 focus:bg-blue-300">
                        <span x-ucfirst>Save</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        if (queries().client) {
            const client = document.querySelector("#client");
            Array.from(client.options).forEach((option, i) => {
                if (option.value === queries().client) option.setAttribute('selected', '');
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('communs.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmedqo\Desktop\project-managment-app\resources\views/contact/create.blade.php ENDPATH**/ ?>