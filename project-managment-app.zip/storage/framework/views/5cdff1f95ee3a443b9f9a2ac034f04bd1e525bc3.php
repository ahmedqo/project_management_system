
<?php $__env->startSection('title', 'Discharges new'); ?>

<?php $__env->startSection('content'); ?>
    <div class="w-full bg-white rounded-lg -mt-12 overflow-hidden">
        <div class="p-4 flex items-center justify-between gap-4">
            <h1 class="font-black text-gray-900 text-2xl">
                <?php echo e(__('Discharges \ New')); ?>

            </h1>
        </div>
    </div>

    <div class="grid grid-rows-1 grid-cols-1 gap-4">
        <div class="w-full bg-white p-4 rounded-lg ">
            <form action="<?php echo e(route('actions.discharges.store')); ?>" method="POST" class="w-full flex flex-col gap-4">
                <?php echo csrf_field(); ?>
                <div class="grid grid-rows-1 grid-cols-1 lg:grid-cols-2 gap-4">
                    <div class="w-full">
                        <label for="employee" class="block text-sm font-black text-gray-900 mb-1">Employee</label>
                        <div class="relative">
                            <select x-select id="employee" placeholder="Employee" name="employee">
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($employee->id); ?>">
                                        <?php echo e($employee->firstName); ?> <?php echo e(strtoupper($employee->lastName)); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="w-full">
                        <label for="date" class="block text-sm font-black text-gray-900 mb-1">Date</label>
                        <div class="relative">
                            <input x-date type="text" id="date" placeholder="Date" name="date" />
                        </div>
                    </div>
                </div>
                <div class="grid grid-rows-1 grid-cols-1 lg:grid-cols-2 gap-4">
                    <div class="w-full">
                        <label for="reason" class="block text-sm font-black text-gray-900 mb-1">Reason</label>
                        <div class="relative">
                            <select x-select id="reason" placeholder="Reason" name="reason">
                                <option value="other">Other</option>
                                <optgroup label="Redundancy">
                                    <option value="lack of work">Lack of work</option>
                                    <option value="business closed down">Business closed down</option>
                                </optgroup>
                                <optgroup label="End of contract">
                                    <option value="end of definite Contract">End of definite Contract</option>
                                    <option value="end of apprenticeship scheme contract">
                                        End of apprenticeship scheme contract
                                    </option>
                                    <option value="end of work phase">End of work phase</option>
                                    <option value="expiry of appointment">Expiry of appointment</option>
                                </optgroup>
                                <optgroup label="Circumstances">
                                    <option value="failing to obtain (Driving / Operating) licence">
                                        Failing to obtain (Driving / Operating) licence
                                    </option>
                                    <option value="failing to pass physical (Training / Aptitude) test">
                                        Failing to pass physical (Training / Aptitude) test
                                    </option>
                                    <option value="revocation of employment license">Revocation of employment license
                                    </option>
                                    <option value="(Cancellation / Suspension) of employment licence">
                                        (Cancellation / Suspension) of employment licence
                                    </option>
                                    <option value="expiry of employment licence">Expiry of employment licence</option>
                                    <option value="court (Injunction / Interdiction / Sentence)">
                                        Court (Injunction / Interdiction / Sentence)
                                    </option>
                                </optgroup>
                                <optgroup label="Dismissed">
                                    <option value="disciplinary reasons">Disciplinary reasons</option>
                                    <option value="failure to perform duties">Failure to perform duties</option>
                                </optgroup>
                                <optgroup label="Resignation">
                                    <option value="formal resignation">Formal resignation</option>
                                    <option value="did not report for work">Did not report for work</option>
                                    <option value="abandoned place of work">Abandoned place of work</option>
                                    <option value="early retirement">Early retirement</option>
                                    <option value="retirement disciplinary corp member">
                                        Retirement disciplinary corp member
                                    </option>
                                    <option value="retirement age">Retirement age</option>
                                    <option value="emigrated">Emigrated</option>
                                    <option value="employed elsewhere">Employed elsewhere</option>
                                    <option value="ended self-employment">Ended self-employment</option>
                                    <option value="further studies">Further studies</option>
                                </optgroup>
                                <optgroup label="Changes within">
                                    <option value="(Transferred / Moved) to another department">
                                        (Transferred / Moved) to another department
                                    </option>
                                    <option value="transfer of business">Transfer of business</option>
                                    <option value="change in company name">Change in company name</option>
                                </optgroup>
                                <optgroup label="Deceased">
                                    <option value="deceased">Deceased</option>
                                </optgroup>
                                <optgroup label="Employer">
                                    <option value="employee reaches pension age">Employee reaches pension age</option>
                                    <option value="health reason">Health reason</option>
                                </optgroup>
                            </select>
                        </div>
                    </div>
                    <div class="w-full">
                        <label for="status" class="block text-sm font-black text-gray-900 mb-1">Status</label>
                        <div class="relative">
                            <select x-select id="status" placeholder="Status" name="status">
                                <option value="1">On</option>
                                <option value="0">Off</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="w-full">
                    <label for="document" class="block text-sm font-black text-gray-900 mb-1">Documents</label>
                    <div class="bg-gray-50 border border-gray-300 text-gray-900 rounded-md overflow-hidden">
                        <div class="relative w-full">
                            <input id="document" type="file"
                                class="opacity-0 block absolute top-0 left-0 w-full h-full cursor-pointer" name="document"
                                onchange="upload(this)" multiple />
                            <input readonly id="text-display" type="text" placeholder="Documents"
                                class="appearance-none bg-transparent text-gray-900 text-md rounded-md block w-full pr-10 p-2 focus:outline-1 outline-blue-400" />
                            <span
                                class="flex w-6 h-6 items-center justify-center absolute right-2 top-1/2 -translate-y-1/2">
                                <svg class="block w-4 h-4 text-gray-900 pointer-events-none" fill="currentcolor"
                                    viewBox="0 0 48 48">
                                    <path
                                        d="M24 31.25q-1 0-1.65-.675Q21.7 29.9 21.7 29V13.45l-4.1 4.1q-.65.6-1.575.625-.925.025-1.525-.675-.7-.65-.7-1.6 0-.95.7-1.7l7.9-7.9q.3-.25.725-.45t.875-.2q.45 0 .875.2t.725.45l7.95 8q.7.65.675 1.6-.025.95-.675 1.6-.6.65-1.55.625-.95-.025-1.65-.675l-4.1-4V29q0 .9-.625 1.575Q25 31.25 24 31.25ZM10.25 42.2q-1.8 0-3.175-1.35Q5.7 39.5 5.7 37.55V30.5q0-.95.675-1.625T8 28.2q1 0 1.625.675t.625 1.625v7.1H37.7v-7.1q0-.95.65-1.625t1.6-.675q1 0 1.65.675.65.675.65 1.625v7.1q0 1.9-1.4 3.25T37.7 42.2Z" />
                                </svg>
                            </span>
                        </div>
                        <div class="flex flex-col"></div>
                    </div>
                </div>
                <div class="w-full">
                    <label for="description" class="block text-sm font-black text-gray-900 mb-1">Description</label>
                    <div class="relative">
                        <textarea x-rich id="description"" placeholder="Description" name="description"
                            class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400"></textarea>
                    </div>
                </div>
                <div class="w-full">
                    <button type="submit"
                        class="appearance-none lg:w-max ml-auto text-md flex items-center justify-center rounded-md font-semibold w-full p-2 px-4 text-white outline-none bg-blue-400 hover:bg-blue-300 focus:bg-blue-300">
                        <span>Save</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('communs.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmedqo\Desktop\rentify-app\resources\views/discharge/create.blade.php ENDPATH**/ ?>