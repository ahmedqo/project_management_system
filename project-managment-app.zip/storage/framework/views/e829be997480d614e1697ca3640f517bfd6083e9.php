
<?php $__env->startSection('title', 'Edit Contact #' . $data->id); ?>

<?php $__env->startSection('content'); ?>
    <div class="w-full bg-white rounded-lg -mt-12 overflow-hidden">
        <div class="p-4 flex items-center justify-between gap-4">
            <h1 class="font-black text-gray-900 text-2xl">
                Edit Contact #<?php echo e($data->id); ?>

            </h1>
        </div>
    </div>

    <div class="grid grid-rows-1 grid-cols-1 gap-4">
        <div class="w-full bg-white p-4 rounded-lg ">
            <form action="<?php echo e(route('actions.contacts.update', $data->id)); ?>" method="POST" class="w-full flex flex-col gap-4">
                <?php echo csrf_field(); ?>
                <div class="w-full">
                    <label x-ucfirst for="client" class="block text-sm font-black text-gray-900 mb-1">Client</label>
                    <div class="relative">
                        <select x-select id="client" placeholder="Client" name="client">
                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option x-ucfirst value="<?php echo e($client->id); ?>"
                                    <?php if($client->id == $data->client): ?> selected <?php endif; ?>>
                                    <?php echo e($client->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="grid grid-rows-1 grid-cols-1 lg:grid-cols-3 gap-4">
                    <div class="w-full">
                        <label x-ucfirst for="title" class="block text-sm font-black text-gray-900 mb-1">Title</label>
                        <div class="relative">
                            <select x-select id="title" placeholder="Title" name="title">
                                <option x-ucfirst value="madame" <?php if($data->title == 'madame'): ?> selected <?php endif; ?>>Madame
                                </option>
                                <option x-ucfirst value="mister" <?php if($data->title == 'mister'): ?> selected <?php endif; ?>>Mister
                                </option>
                            </select>
                        </div>
                    </div>
                    <div class="w-full">
                        <label x-ucfirst for="firstName" class="block text-sm font-black text-gray-900 mb-1">First
                            name</label>
                        <div class="relative">
                            <input id="firstName" type="text" placeholder="First name" name="firstName"
                                value="<?php echo e($data->firstName); ?>"
                                class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400" />
                        </div>
                    </div>
                    <div class="w-full">
                        <label x-ucfirst for="lastName" class="block text-sm font-black text-gray-900 mb-1">Last
                            name</label>
                        <div class="relative">
                            <input id="lastName" type="text" placeholder="Last name" name="lastName"
                                value="<?php echo e($data->lastName); ?>"
                                class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400" />
                        </div>
                    </div>
                </div>
                <div class="grid grid-rows-1 grid-cols-1 lg:grid-cols-3 gap-4">
                    <div class="w-full">
                        <label x-ucfirst for="function" class="block text-sm font-black text-gray-900 mb-1">Function</label>
                        <input id="function" type="text" placeholder="Function" name="function"
                            value="<?php echo e($data->function); ?>"
                            class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400" />
                    </div>
                    <div class="w-full">
                        <label x-ucfirst for="email" class="block text-sm font-black text-gray-900 mb-1">Email</label>
                        <div class="relative">
                            <input id="email" type="email" placeholder="Email" name="email"
                                value="<?php echo e($data->email); ?>"
                                class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400" />
                        </div>
                    </div>
                    <div class="w-full">
                        <label x-ucfirst for="phone" class="block text-sm font-black text-gray-900 mb-1">Phone</label>
                        <div class="relative">
                            <input id="phone" type="tel" placeholder="Phone" name="phone"
                                value="<?php echo e($data->phone); ?>"
                                class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full p-2 focus:outline-1 outline-blue-400" />
                        </div>
                    </div>
                </div>
                <div class="w-full">
                    <button type="submit"
                        class="appearance-none lg:w-max ml-auto text-md flex items-center justify-center rounded-md font-semibold w-full p-2 px-4 text-white outline-none bg-blue-400 hover:bg-blue-300 focus:bg-blue-300">
                        <span x-ucfirst>Save</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('communs.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmedqo\Desktop\rentify-app\resources\views/contact/edit.blade.php ENDPATH**/ ?>