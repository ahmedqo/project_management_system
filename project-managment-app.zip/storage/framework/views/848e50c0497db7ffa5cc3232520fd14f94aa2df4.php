
<?php $__env->startSection('title', 'Settings'); ?>

<?php $__env->startSection('content'); ?>
    <div class="w-full bg-white rounded-lg shadow-sm shadow-gray-300 -mt-12 overflow-hidden">
        <div class="p-4 flex items-center justify-between gap-4">
            <h1 class="font-black text-gray-900 text-2xl">
                <?php echo e(__('Settings')); ?>

            </h1>
        </div>
    </div>

    <div class="grid grid-rows-1 grid-cols-1 gap-4">
        <div class="w-full bg-white p-4 rounded-lg shadow-sm shadow-gray-300">
            <form action="<?php echo e(route('actions.employees.password')); ?>" method="POST" class="w-full flex flex-col gap-4">
                <?php echo csrf_field(); ?>
                <div class="w-full">
                    <label for="oldPassword" class="block text-sm font-black text-gray-900 mb-1">Old password</label>
                    <div class="relative">
                        <input id="oldPassword" type="password" placeholder="Old password" name="oldPassword"
                            class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full pr-10 p-2 focus:outline-1 outline-blue-400" />
                        <button type="button"
                            onclick="oldPassword.type = oldPassword.type == 'password' ? 'text' : 'password'"
                            x-toggle="#oldPasswordIcon path" x-property="hidden"
                            class="absolute right-2 top-1/2 -translate-y-1/2 appearance-none rounded-md focus:outline-1 outline-blue-400">
                            <svg id="oldPasswordIcon" class="block w-6 h-6 text-gray-900 pointer-events-none"
                                fill="currentcolor" viewBox="0 0 48 48">
                                <path
                                    d="M24 31.35q3.5 0 5.925-2.45T32.35 23q0-3.5-2.45-5.925T24 14.65q-3.5 0-5.925 2.45T15.65 23q0 3.5 2.45 5.925T24 31.35Zm0-3.55q-2 0-3.4-1.425T19.2 23q0-2 1.425-3.4T24 18.2q2 0 3.4 1.425T28.8 23q0 2-1.425 3.4T24 27.8ZM24 39q-7.2 0-13.05-3.95-5.85-3.95-9.1-10.4-.2-.3-.3-.75-.1-.45-.1-.9t.1-.9q.1-.45.3-.85 3.25-6.35 9.1-10.3Q16.8 7 24 7q7.2 0 13.05 3.95 5.85 3.95 9.1 10.3.2.4.3.85.1.45.1.85 0 .45-.1.925-.1.475-.3.775-3.25 6.45-9.1 10.4T24 39Z" />
                                <path class="hidden"
                                    d="m39 33.7-7.4-7.4q.4-.6.575-1.55.175-.95.175-1.75 0-3.5-2.425-5.925T24 14.65q-.85 0-1.65.175-.8.175-1.65.575l-6.4-6.45q1.7-.7 4.525-1.325T24.25 7q6.8 0 12.775 3.775Q43 14.55 46.25 21.25q.15.4.225.85.075.45.075.9t-.075.925q-.075.475-.275.775-1.35 2.8-3.2 5.025-1.85 2.225-4 3.975Zm.1 10-6.45-6.25q-1.75.7-3.975 1.125Q26.45 39 24 39q-7.05 0-12.975-3.775T1.8 24.65q-.2-.35-.275-.775Q1.45 23.45 1.45 23t.1-.95q.1-.5.25-.85 1.05-2.15 2.675-4.25 1.625-2.1 3.675-4.1L3.3 7.95q-.5-.4-.5-1.125T3.3 5.6q.4-.45 1.15-.45.75 0 1.25.45l35.8 35.8q.45.5.375 1.175-.075.675-.375 1.075-.55.55-1.275.55-.725 0-1.125-.5ZM24 31.35q.6 0 1.225-.15.625-.15 1.025-.3L16 20.75q-.1.5-.225 1.1-.125.6-.125 1.15 0 3.55 2.45 5.95 2.45 2.4 5.9 2.4Zm4.1-8.6-3.6-3.6q1.35-.9 2.95.35t.65 3.25Z" />
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="grid grid-rows-1 grid-cols-1 lg:grid-cols-2 gap-4">
                    <div class="w-full">
                        <label for="newPassword" class="block text-sm font-black text-gray-900 mb-1">New password</label>
                        <div class="relative">
                            <input id="newPassword" type="password" placeholder="New password" name="newPassword"
                                class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full pr-10 p-2 focus:outline-1 outline-blue-400" />
                            <button type="button"
                                onclick="newPassword.type = newPassword.type == 'password' ? 'text' : 'password'"
                                x-toggle="#newPasswordIcon path" x-property="hidden"
                                class="absolute right-2 top-1/2 -translate-y-1/2 appearance-none rounded-md focus:outline-1 outline-blue-400">
                                <svg id="newPasswordIcon" class="block w-6 h-6 text-gray-900 pointer-events-none"
                                    fill="currentcolor" viewBox="0 0 48 48">
                                    <path
                                        d="M24 31.35q3.5 0 5.925-2.45T32.35 23q0-3.5-2.45-5.925T24 14.65q-3.5 0-5.925 2.45T15.65 23q0 3.5 2.45 5.925T24 31.35Zm0-3.55q-2 0-3.4-1.425T19.2 23q0-2 1.425-3.4T24 18.2q2 0 3.4 1.425T28.8 23q0 2-1.425 3.4T24 27.8ZM24 39q-7.2 0-13.05-3.95-5.85-3.95-9.1-10.4-.2-.3-.3-.75-.1-.45-.1-.9t.1-.9q.1-.45.3-.85 3.25-6.35 9.1-10.3Q16.8 7 24 7q7.2 0 13.05 3.95 5.85 3.95 9.1 10.3.2.4.3.85.1.45.1.85 0 .45-.1.925-.1.475-.3.775-3.25 6.45-9.1 10.4T24 39Z" />
                                    <path class="hidden"
                                        d="m39 33.7-7.4-7.4q.4-.6.575-1.55.175-.95.175-1.75 0-3.5-2.425-5.925T24 14.65q-.85 0-1.65.175-.8.175-1.65.575l-6.4-6.45q1.7-.7 4.525-1.325T24.25 7q6.8 0 12.775 3.775Q43 14.55 46.25 21.25q.15.4.225.85.075.45.075.9t-.075.925q-.075.475-.275.775-1.35 2.8-3.2 5.025-1.85 2.225-4 3.975Zm.1 10-6.45-6.25q-1.75.7-3.975 1.125Q26.45 39 24 39q-7.05 0-12.975-3.775T1.8 24.65q-.2-.35-.275-.775Q1.45 23.45 1.45 23t.1-.95q.1-.5.25-.85 1.05-2.15 2.675-4.25 1.625-2.1 3.675-4.1L3.3 7.95q-.5-.4-.5-1.125T3.3 5.6q.4-.45 1.15-.45.75 0 1.25.45l35.8 35.8q.45.5.375 1.175-.075.675-.375 1.075-.55.55-1.275.55-.725 0-1.125-.5ZM24 31.35q.6 0 1.225-.15.625-.15 1.025-.3L16 20.75q-.1.5-.225 1.1-.125.6-.125 1.15 0 3.55 2.45 5.95 2.45 2.4 5.9 2.4Zm4.1-8.6-3.6-3.6q1.35-.9 2.95.35t.65 3.25Z" />
                                </svg>
                            </button>
                        </div>
                    </div>
                    <div class="w-full">
                        <label for=confirmPassword" class="block text-sm font-black text-gray-900 mb-1">Confirm
                            password</label>
                        <div class="relative">
                            <input id="confirmPassword" type="password" placeholder="Confirm password"
                                name="confirmPassword"
                                class="appearance-none bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-md block w-full pr-10 p-2 focus:outline-1 outline-blue-400" />
                            <button type="button"
                                onclick="confirmPassword.type = confirmPassword.type == 'password' ? 'text' : 'password'"
                                x-toggle="#confirmPasswordIcon path" x-property="hidden"
                                class="absolute right-2 top-1/2 -translate-y-1/2 appearance-none rounded-md focus:outline-1 outline-blue-400">
                                <svg id="confirmPasswordIcon" class="block w-6 h-6 text-gray-900 pointer-events-none"
                                    fill="currentcolor" viewBox="0 0 48 48">
                                    <path
                                        d="M24 31.35q3.5 0 5.925-2.45T32.35 23q0-3.5-2.45-5.925T24 14.65q-3.5 0-5.925 2.45T15.65 23q0 3.5 2.45 5.925T24 31.35Zm0-3.55q-2 0-3.4-1.425T19.2 23q0-2 1.425-3.4T24 18.2q2 0 3.4 1.425T28.8 23q0 2-1.425 3.4T24 27.8ZM24 39q-7.2 0-13.05-3.95-5.85-3.95-9.1-10.4-.2-.3-.3-.75-.1-.45-.1-.9t.1-.9q.1-.45.3-.85 3.25-6.35 9.1-10.3Q16.8 7 24 7q7.2 0 13.05 3.95 5.85 3.95 9.1 10.3.2.4.3.85.1.45.1.85 0 .45-.1.925-.1.475-.3.775-3.25 6.45-9.1 10.4T24 39Z" />
                                    <path class="hidden"
                                        d="m39 33.7-7.4-7.4q.4-.6.575-1.55.175-.95.175-1.75 0-3.5-2.425-5.925T24 14.65q-.85 0-1.65.175-.8.175-1.65.575l-6.4-6.45q1.7-.7 4.525-1.325T24.25 7q6.8 0 12.775 3.775Q43 14.55 46.25 21.25q.15.4.225.85.075.45.075.9t-.075.925q-.075.475-.275.775-1.35 2.8-3.2 5.025-1.85 2.225-4 3.975Zm.1 10-6.45-6.25q-1.75.7-3.975 1.125Q26.45 39 24 39q-7.05 0-12.975-3.775T1.8 24.65q-.2-.35-.275-.775Q1.45 23.45 1.45 23t.1-.95q.1-.5.25-.85 1.05-2.15 2.675-4.25 1.625-2.1 3.675-4.1L3.3 7.95q-.5-.4-.5-1.125T3.3 5.6q.4-.45 1.15-.45.75 0 1.25.45l35.8 35.8q.45.5.375 1.175-.075.675-.375 1.075-.55.55-1.275.55-.725 0-1.125-.5ZM24 31.35q.6 0 1.225-.15.625-.15 1.025-.3L16 20.75q-.1.5-.225 1.1-.125.6-.125 1.15 0 3.55 2.45 5.95 2.45 2.4 5.9 2.4Zm4.1-8.6-3.6-3.6q1.35-.9 2.95.35t.65 3.25Z" />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="w-full">
                    <button type="submit"
                        class="appearance-none lg:w-max ml-auto text-md flex items-center justify-center rounded-md font-semibold w-full p-2 px-4 text-white outline-none bg-blue-400 hover:bg-blue-300 focus:bg-blue-300">
                        <span>Save</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('communs.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmedqo\Desktop\rentify-app\resources\views/employee/settings.blade.php ENDPATH**/ ?>